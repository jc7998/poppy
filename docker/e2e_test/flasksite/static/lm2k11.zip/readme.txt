* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * 
                         The Literary Machine
                         
                � 1997-2005, Gunnar Sommestad.

                            License: Freeware
* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

Welcome to The Literary Machine 2000! Please take a
few minutes to read this file, which contains the latest
information regarding the program.


Contents
----------------------

About LM 2000
Installation & Setup
     Installing LM for the First Time
          Setting Up Your Browser
     Installing an Update
About the Database Engine
A Note to WordPerfect Users
A Note to Users Upgrading from LM 3x
Known Issues
Where can I get help?
     Contact Information


About LM 2000
----------------------

Written in Delphi, The Literary Machine was published as
freeware in 1997. The extended 32 bit-version, LM 2000,
was released in August 2000. 

Though I remain committed to fix any material bug brought
to light in LM 2000, its development was discontinued in
March 2002 at the debut of LM Professional Edition. This
latest release (September 2003)supplies LM 2000 with
a commercial-quality Help System.

This installation build contains LM 2000 version 1.130B.


Installation & Setup
----------------------

There are two kinds of installation packages:
   o   the complete installation package (5.2 MB)
   o   an update package (<1 MB)

The complete installation package is for new users.
It requires: 
   o   Windows 98 or better
   o   32 MB RAM (memory)
   o   16-bit color display (i.e., millions of colors--High
        Color or True Color)


Installing LM for the first time
----------------------

For illustrated instructions and additional resources, visit
the Downloads Area at the LM Web site. See 
http://www.literarymachine.com 


These are the files you should receive in the complete
installation package:

          setup.exe
          readme.txt



To install the complete installation package:

1. Use a recent version of an unzipping utility
    to extract (unzip) the installation package to
    an empty temporary folder.
2. Close any running programs. And be sure no
    virus-checker is running.
3. Go to the temporary folder and double-click the file
    named SETUP.EXE.
4. Follow the on-screen directions.

For instructions on how to use your unzipping utility, see
that program's documentation. If you do not have such a
program, you can download a free trial of "WinZip" at
http://www.winzip.com/ddchomea.htm. If you
are comfortable running a DOS program, we recommend
INFO-Zip's "UnZip," which you can download free at
http://www.info-zip.org.  




Setting Up Your Browser
----------------------

When you click projects that are URLs, LM launches
another program--a browser--to display those files.
To enable this feature, you must introduce LM to the
browser you want it to use.

1. Choose Installation > Browser Setup. The Select Web
    Browser dialog box appears.
2. If the Browser you wish to set up is Netscape, set
    the Type radio button to "Netscape." If it is Internet
    Explorer, Opera, or any other browser, leave the
    Browser Type radio button set to "Internet Explorer."
3. Press the Search button to have LM search for the
    default browser, or press the browse button to navigate
    to the executable file (EXE-file) for the browser you wish
    LM to use.

Note: To find the executable file of a browser, right-click a
         shortcut to it, choose Properties, and copy the
         highlighted text in the Target field. That's the
         executable file's full name = path + short name. For
         example: "C:\Program Files\Sommestad\Literary
         Machine2000\lm.exe" is the full name of the file
         whose short name is "lm.exe."

Note: Due to its lack of DDE functionality, Netscape 6 is
not supported.



Installing an Update
----------------------

Should an update become available, you can download it
at 
   1. http://www.literarymachine.com/LM_2_1.htm
   2. http://groups.yahoo.com/group/literarymachine/files/
       LM%202000%20Version%201.1%20Updates/

These are the files you should receive in the update
package:

          empty.wav *
          LM_Program_Fixes.txt
          LMbeta_mods-history.txt 
          Lm.exe 
          readme.txt     
          
     * This is the default silent sound file that triggers
        the audio system. It is necessary for upgrading
        LM2000 1.0 to LM2000 1.1. 
         
One or two informational files may also be included.

To install an update package (over an existing installation
of LM)

1. Use WinZip or a similar utility program to unzip the files
    in the update package to the LM2000 program directory.
2. Choose to overwrite existing files.



About the Database Engine
----------------------

The Literary Machine is a Paradox database that relies on
the Borland Database Engine (BDE). Unless the BDE
already exists on your computer, the complete installation
package installs it. 


A Note to WordPerfect Users
---------------------

WordPerfect Suite programs also install and rely on the
BDE. A couple minor conflicts with easy workarounds sometimes
occur. So, WordPerfect users should read the "Conflicts"
topic in the "Troubleshooting" chapter of Help.



A Note to Users Upgrading from LM 3x
---------------------

If you are upgrading from the pre-millennium 3x version of
The Literary Machine:

   1. Install LM 2000 as a new user.
   2. Import an LM 3x archive file. 
 


Known Issues
----------------------

When you create a new project, click on another project,
then back on the new one BEFORE you try to add any
items to it. Clicking away updates the project list in the
database. Till that update, your new project doesn't really
exist.

The Borland Database Engine cannot read path names
longer than 78 characters. So, if you do not install
LM 2000 to the default directory, make sure that the
directory you choose has a full name of less than 40
characters.

Read more about known issues and problems at:
http://www.literarymachine.com/LM_3_7.htm



Where can I find help?
----------------------

In addition to the program's revised internal Help system,
visit:

1. the Literary Machine Web site
   at http://www.literarymachine.com

2. the literarymachine groyp at Yahoo
   http://groups.yahoo.com/group/literarymachine/

3. the Literary Machine Resources at
   http://operationdoubles.com/lm_site/index.htm




Contact Information
----------------------

To report a bug or contact the program's author, email
Gunnar Sommestad at gunnar@sommestad.com
or support@literarymachine.com

Gunnar Sommestad 
October 2000, May 2002, September 2003, December 2004 
  
  
  
  
  
